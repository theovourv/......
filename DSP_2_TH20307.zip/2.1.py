#!/usr/bin/env python
# coding: utf-8

# In[6]:


import numpy as np
import matplotlib.pyplot as plt
from scipy import signal

def z_transform(a, u):
    z_transformed = [] 
    for n in range(len(u)):
        if n == 0:
            z_transformed.append(1)  # Για n=0, το αποτέλεσμα είναι 1 / (1 - a * z^(-1))
        else:
            z_transformed.append(a * z_transformed[-1])  # Ανανέωση του αποτελέσματος με βάση τον τύπο της αναδρομικής σχέσης
    return z_transformed

if __name__ == "__main__":
    a = 0.5
    input_sequence = [1, 2, 3, 4, 5]  # Παράδειγμα εισόδου u(n)
    result = z_transform(a, input_sequence)
    print("Το αποτέλεσμα είναι:", result)



# In[ ]:




