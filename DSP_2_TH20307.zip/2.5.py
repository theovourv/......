#!/usr/bin/env python
# coding: utf-8

# In[ ]:


from sympy import symbols, apart, residue


z = symbols('z')

X_z = z**-4/(z-1) + z**-6 + z**-3/(z+0.5)

# Αποσύνθεση της συνάρτησης X(z)
X_inv_z = apart(X_z)
poles = [1, -0.5]  # Πόλοι της συνάρτησης μεταφοράς

residues = {}
for pole in poles:
    res = residue(X_z, z, pole)
    residues[pole] = res

# Αντιστροφή των πόλων
for pole, residue_val in residues.items():
    X_inv_z += residue_val / (z - pole)

print("Ο αντίστροφος μετασχηματισμός X(z) είναι:")
print(X_inv_z)

