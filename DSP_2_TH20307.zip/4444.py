#!/usr/bin/env python
# coding: utf-8

# In[5]:


import numpy as np
import matplotlib.pyplot as plt
from scipy import signal
fs = 25000  
cutoff_low = 4000  # Συχνότητα κοπής χαμηλού περάσματος 
cutoff_high = 12000  # Συχνότητα κοπής υψηλού περάσματος 

attenuation_low = 2  # Μέγιστη εξασθένιση 
attenuation_high = 30  # Ελάχιστη εξασθένιση 




# Τάξη φίλτρου
N, Wn = signal.ellipord(cutoff_low, cutoff_high, attenuation_low, attenuation_high, analog=True)

# Φίλτρο
b, a = signal.ellip(N, attenuation_low, attenuation_high, Wn, btype='low', analog=True)

# Απόκριση συχνότητας φίλτρου
w, h = signal.freqs(b, a, worN=1000)


plt.figure()
plt.semilogx(w, 20 * np.log10(abs(h)))
plt.title('Φίλτρο απόκρισης συχνότητας')
plt.xlabel('Συχνότητα [Hz]')
plt.ylabel('Εξασθένιση [dB]')
plt.grid()
plt.show()



# In[ ]:




