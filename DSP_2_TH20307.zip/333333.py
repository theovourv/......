#!/usr/bin/env python
# coding: utf-8

# In[5]:


import numpy as np
import matplotlib.pyplot as plt
from scipy import signal

fs = 25000  
cutoff_low = 5000  # Συχνότητα αποκοπής χαμηλού περάσματος σε Hz
cutoff_high = 12000  # Συχνότητα αποκοπής 
attenuation_low = 1  # Μέγιστη εξασθένιση
attenuation_high = 20  # Ελάχιστη εξασθένιση

# Υπολογισμός τάξης φίλτρου
N, Wn = signal.buttord([cutoff_low, cutoff_high], [cutoff_low*0.9, cutoff_high*1.1], attenuation_low, attenuation_high, analog=True)

# Κατασκευή φίλτρου
b, a = signal.butter(N, Wn, btype='band', analog=True)

w, h = signal.freqs(b, a, worN=1000)

plt.figure()
plt.semilogx(w, 20 * np.log10(abs(h)))
plt.title(' Φίλτρο απόκρισης συχνότητας')
plt.xlabel('Συχνότητα [Hz]')
plt.ylabel('Εξασθένιση [dB]')
plt.grid()
plt.show()



# In[ ]:




